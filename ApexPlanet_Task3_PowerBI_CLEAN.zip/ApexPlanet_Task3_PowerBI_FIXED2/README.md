# ApexPlanet Task 3 - Deep Dive Analysis & Interactive Dashboard

This Power BI Project uses the cleaned ApexPlanet sales dataset.

## Required data file
Place the cleaned dataset at:
`C:\Users\Ayush Rathor\Downloads\Cleaned_ApexPlanet_Sales_Dataset(1).xlsx`

The included `data/` folder contains the same cleaned workbook for reference.

## Dashboard pages
1. **Sales Overview** - 5 core KPIs, category revenue, monthly revenue trend, product revenue, gender revenue, category/city slicers.
2. **Customer Deep Dive** - customer segmentation distribution, segment revenue, segment KPIs, city/segment slicers, and customer detail table.

## Customer segmentation rules
- High Value: Total Revenue >= 300,000 and Total Orders >= 2
- Loyal: Total Orders >= 2 and Recency <= 90 days
- At Risk: Recency > 180 days
- New / Recent: Total Orders = 1 and Recency <= 90 days
- Regular: all remaining customers

## Open
Extract the project folder and open `ApexPlanet_Task3_PowerBI.pbip` in Power BI Desktop.
